<?php

namespace App\Http\Controllers;

class BaseController extends Controller
{
}
